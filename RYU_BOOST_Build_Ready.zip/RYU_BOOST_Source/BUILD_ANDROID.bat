@echo off
chcp 65001 >nul
title RYU BOOST - Android Build
echo ==========================================
echo   RYU BOOST - Prepare Android APK
echo ==========================================
where node >nul 2>nul
if errorlevel 1 (
  echo Please install Node.js LTS first: https://nodejs.org/
  pause
  exit /b 1
)
call npm install
if errorlevel 1 goto error
call npm run android:init
if errorlevel 1 goto error
echo.
echo Android project prepared.
echo If Android Studio is installed, it will now open the project.
call npx cap open android
echo.
echo In Android Studio wait for Gradle sync, then use Build ^> Build APK(s).
echo Debug APK is normally placed in androidppuild\outputspk\debugpp-debug.apk
pause
exit /b 0
:error
echo.
echo Build failed. Read the error above and check README_AR.txt.
pause
exit /b 1
