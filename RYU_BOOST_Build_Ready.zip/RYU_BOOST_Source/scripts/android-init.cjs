const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const androidDir = path.join(process.cwd(), 'android');
if (!fs.existsSync(androidDir)) {
  const add = spawnSync('npx', ['cap', 'add', 'android'], { stdio: 'inherit', shell: process.platform === 'win32' });
  if (add.status !== 0) process.exit(add.status || 1);
}
const sync = spawnSync('npx', ['cap', 'sync', 'android'], { stdio: 'inherit', shell: process.platform === 'win32' });
process.exit(sync.status || 0);
