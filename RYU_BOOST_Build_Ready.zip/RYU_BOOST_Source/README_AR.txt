RYU BOOST — مشروع تجهيز نسخة Windows وAndroid للاختبار
=====================================================

مهم:
- هذا مجلد مصدر لبناء التطبيق، وليس ملف EXE أو APK جاهزاً.
- لا يمكن إخراج ملفات التثبيت النهائية إلا على جهاز تتوفر عليه الأدوات المطلوبة.
- البرنامج الحالي أداة توصيات وحساسية؛ لا يغيّر Registry أو إعدادات اللعبة أو DPI تلقائياً.
- توصيات الحساسية مبدئية وليست ضماناً لأفضل نتيجة على كل جهاز.

أولاً: بناء نسخة Windows (EXE/Installer)
-----------------------------------------
1) ثبّت Node.js LTS من: https://nodejs.org/
2) فك ضغط المشروع في مجلد بسيط مثل C:\RYU_BOOST_Source
3) افتح المجلد.
4) انقر مرتين على BUILD_WINDOWS.bat
5) بعد انتهاء البناء ابحث داخل مجلد dist عن ملف تثبيت RYU BOOST.

بديل عبر الطرفية:
  npm install
  npm run desktop:dist

ثانياً: تجهيز نسخة Android (APK)
--------------------------------
المطلوب:
- Node.js LTS: https://nodejs.org/
- Android Studio: https://developer.android.com/studio
- أثناء إعداد Android Studio ثبّت Android SDK وأدوات Build Tools المطلوبة.

الخطوات:
1) فك الضغط عن المشروع.
2) انقر مرتين على BUILD_ANDROID.bat.
3) سيتجهّز مجلد android ويفتح Android Studio.
4) انتظر اكتمال Gradle Sync.
5) من Android Studio اختر Build > Build APK(s).
6) ملف APK التجريبي يكون غالباً في:
   android\app\build\outputs\apk\debug\app-debug.apk

ملاحظات للاختبار:
- اسم التطبيق RYU BOOST ومعرّف الحزمة com.ryuboost.app.
- اختبر APK على جهاز تملكه أو لديك إذن بتجربته عليه.
- لا ترفع نسخة debug على متجر عام؛ قبل النشر تحتاج توقيع إصدار release ومراجعة الأذونات والخصوصية.
- لا تدخل بيانات حساسة. المشروع لا يحتاج حساباً أو كلمة مرور.

استكشاف الأخطاء:
- إذا ظهر خطأ في npm install، تأكد من اتصال الإنترنت وإصدار Node.js.
- إذا فشل Android Gradle Sync، افتح SDK Manager وثبّت SDK المطلوب حسب رسالة الخطأ.
- لا تشارك مجلد node_modules أو ملفات التوقيع الخاصة بك مع الآخرين.


طريقة بناء تلقائي على GitHub (للحصول على الملفات من الإنترنت)
-------------------------------------------------------------
1) أنشئ حساباً على https://github.com/ إن لم يكن لديك حساب.
2) أنشئ مستودعاً جديداً (Repository) خاصاً أو عاماً.
3) ارفع محتويات هذا المشروع إلى المستودع، مع مجلد .github/workflows/build.yml.
4) افتح تبويب Actions ثم اختر "Build RYU BOOST installers" ثم Run workflow.
5) بعد اكتمال البناء بنجاح، افتح نتيجة التشغيل وابحث عن Artifacts:
   - RYU-BOOST-Windows-EXE
   - RYU-BOOST-Android-APK
6) نزّل كل Artifact وفك ضغطه. ملف APK الناتج نسخة Debug للاختبار فقط.

تنبيه: هذه الخطوات تحتاج حساب GitHub وإجراء الرفع والضغط على Run workflow. لا يوجد رابط عام لملفات EXE/APK قبل اكتمال البناء. لا تنشر ملف Debug APK كتطبيق إنتاجي.
