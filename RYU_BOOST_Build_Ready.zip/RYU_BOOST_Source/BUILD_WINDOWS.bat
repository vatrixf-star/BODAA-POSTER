@echo off
chcp 65001 >nul
title RYU BOOST - Windows Build
echo ==========================================
echo   RYU BOOST - Build Windows Installer
echo ==========================================
where node >nul 2>nul
if errorlevel 1 (
  echo Please install Node.js LTS first: https://nodejs.org/
  pause
  exit /b 1
)
call npm install
if errorlevel 1 goto error
call npm run desktop:dist
if errorlevel 1 goto error
echo.
echo Done! Look inside the dist folder for the Windows installer.
pause
exit /b 0
:error
echo.
echo Build failed. Read the error above and check README_AR.txt.
pause
exit /b 1
